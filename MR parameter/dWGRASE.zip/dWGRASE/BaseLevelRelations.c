/****************************************************************
 * 
 * $Source: /pv/CvsTree/pv/gen/src/prg/methods/RARE/BaseLevelRelations.c,v $ 
 * 
 * Copyright (c) 2002-2005
 * Bruker BioSpin MRI GmbH 
 * D-76275 Ettlingen, Germany 
 * 
 * All Rights Reserved 
 * 
 * $Id: BaseLevelRelations.c,v 1.16.2.11 2006/01/24 17:42:52 sako Exp $ 
 * 
 ****************************************************************/ 
 
static const char resid[] = "$Id: BaseLevelRelations.c,v 1.16.2.11 2006/01/24 17:42:52 sako Exp $(C) 2002-2005 Bruker BioSpin MRI GmbH"; 
 
#define DEBUG  0 
#define DB_MODULE 0 
#define DB_LINE_NR 0 
 
 
#include "method.h" 
 
void SetBaseLevelParam( void ) 
{ 
 
  DB_MSG(("-->SetBaseLevelParam\n")); 
   
  SetBasicParameters(); 
   
   
  if( PVM_ErrorDetected == Yes ) 
  { 
    UT_ReportError("SetBaseLevelParam: Error in function call!"); 
    return; 
  } 
   
  SetFrequencyParameters(); 
   
  if( PVM_ErrorDetected == Yes ) 
  { 
    UT_ReportError("SetBaseLevelParam: In function call!"); 
    return; 
  } 
   
  SetPpgParameters(); 
   
  if( PVM_ErrorDetected == Yes ) 
  { 
    UT_ReportError("SetBaseLevelParam: In function call!"); 
    return; 
  } 
   
  SetGradientParameters(); 
   
  if( PVM_ErrorDetected == Yes ) 
  { 
    UT_ReportError("SetBaseLevelParam: In function call!"); 
    return; 
  } 
   
  SetInfoParameters(); 
   
  if( PVM_ErrorDetected == Yes ) 
  { 
    UT_ReportError("SetBaseLevelParam: In function call!"); 
    return; 
  } 
   
   
  SetMachineParameters(); 
   
  if( PVM_ErrorDetected == Yes ) 
  { 
    UT_ReportError("SetBaseLevelParam: In function call!"); 
    return; 
  } 
 
 
  /* ------------------------------------------------------------------------ 
     Sets parameters needed for multi-receiver acq. Overrides some previously 
     set parameters such as NUCn Must be called at the end of 
     SetBaseLevel. 
     ----------------------------------------------------------------------- */ 
  if(Yes==ATB_SetMultiRec()) 
  { 
    ATB_SetPulprog("dwGRASE4f1.4ch"); 
  } 
   
  /* setting baselevel parameters used by modules */ 
  ATB_SetFatSupBaselevel(); 
  ATB_SetMagTransBaseLevel(); 
  ATB_SetSatSlicesBaseLevel(); 
  ATB_SetFlowSaturationBaseLevel(); 
  ATB_SetTriggerBaseLevel(); 
  ATB_SetEvolutionBaseLevel(); 
  { 
  int nSlices; 
 
  nSlices = GTB_NumberOfSlices( PVM_NSPacks, PVM_SPackArrNSlices ); 
  ATB_SetSelIrBaseLevel(nSlices); 
  } 
  
  /* Start GRASE change */
   ATB_DwAcq(ACQ_O1_list,                                                                                                                      
            GTB_NumberOfSlices( PVM_NSPacks, PVM_SPackArrNSlices ),                                                                           
            ExcSliceGrad,Yes);                                                                                                                
   /* end GRASE change */
   
#if DEBUG 
  printTiming(); 
#endif 
 
  DB_MSG(("<--SetBaseLevelParam\n")); 
   
} 
 
 
 
 
 
void SetBasicParameters( void ) 
{ 
  int spatDim, specDim; 
  int nSlices; 
  int echo; 
/* added by J. Zhang */  
  int acqDim[10]; 
  int i; 
  int rarefactor; 
/* end */ 
 
 
  DB_MSG(("-->SetBasicParameters\n")); 
   
  /* ACQ_dim */ 
   
  spatDim = PTB_GetSpatDim(); 
  if( PVM_ErrorDetected == Yes ) 
  { 
    UT_ReportError("SetBasicParameters: In function call!"); 
    return; 
  } 
   
  specDim = PTB_GetSpecDim(); 
  if( PVM_ErrorDetected == Yes ) 
  { 
    UT_ReportError("SetBasicParameters: In function call!"); 
    return; 
  } 
   
  ACQ_dim = spatDim + specDim; 
  ParxRelsParRelations("ACQ_dim",Yes); 
 
  /* ACQ_dim_desc */ 
   
  ATB_SetAcqDimDesc( specDim, spatDim, NULL ); 
  if( PVM_ErrorDetected == Yes ) 
  { 
    UT_ReportError("SetBasicParameters: In function call!"); 
    return; 
  } 
   
  /* ACQ_size */ 
 
  /* With the Encoding group, this call 
     ATB_SetAcqSize( Spatial, spatDim, PVM_Matrix, PVM_AntiAlias, No ); 
     is replaced by: */ 
  /* with the addition of navigator echo, the dimension of acquisition will increase */ 
  /* so instead of using PVM_Matrix directly, we use navDim instead. */ 
  /* when no navigator, PVM_EncMatrix = PVM_Matrix; */ 
   
  /* the following two lines are now in the parsRelations inside backbone */
  /* rarefactor=PVM_RareFactor+2*navigator_flag; */
  /* PVM_EncMatrix[1]=PVM_EncMatrix[1]+2*navigator_flag*(PVM_Matrix[1]/PVM_RareFactor); */   
  for (i=0;i<spatDim;i++) acqDim[i]=PVM_EncMatrix[i];
  acqDim[0]= (int) (10*((1.0*PVM_EncMatrix[0])/0.8));
  ATB_SetAcqSize( Spatial, spatDim, acqDim, NULL, No );  
   
  if( PVM_ErrorDetected == Yes ) 
  { 
    UT_ReportError("SetBasicParameters: In function call!"); 
    return; 
  } 
   
  /* NSLICES */ 
   
  nSlices = GTB_NumberOfSlices( PVM_NSPacks, PVM_SPackArrNSlices ); 
  if( PVM_ErrorDetected == Yes ) 
  { 
    UT_ReportError("SetBasicParameters: In function call!"); 
    return; 
  } 
   
  ATB_SetNSlices( nSlices ); 
  if( PVM_ErrorDetected == Yes ) 
  { 
    UT_ReportError("SetBasicParameters: In function call!"); 
    return; 
  } 
   
  /* NR */ 
   
  ATB_SetNR( PVM_NRepetitions ); 
  if( PVM_ErrorDetected == Yes ) 
  { 
    UT_ReportError("SetBasicParameters: In function call!"); 
    return; 
  } 
   
  /* NI */ 
   
  ATB_SetNI( nSlices * PVM_NEchoImages); 
  if( PVM_ErrorDetected == Yes ) 
  { 
    UT_ReportError("SetBasicParameters: In function call!"); 
    return; 
  } 
   
   
   
  /* AVERAGING */ 
 
 
  switch(PVM_MotionSupOnOff) 
  { 
  default: 
  case Off: 
    ATB_SetNA( PVM_NAverages ); 
    if( PVM_ErrorDetected == Yes ) 
    { 
      UT_ReportError("SetBasicParameters: In function call!"); 
      return; 
    } 
    ATB_SetNAE( 1 ); 
    if( PVM_ErrorDetected == Yes ) 
    { 
      UT_ReportError("SetBasicParameters: In function call!"); 
      return; 
    } 
    break; 
  case On: 
    ATB_SetNAE( PVM_NAverages ); 
    if( PVM_ErrorDetected == Yes ) 
    { 
      UT_ReportError("SetBasicParameters: In function call!"); 
      return; 
    } 
    ATB_SetNA( 1 ); 
    if( PVM_ErrorDetected == Yes ) 
    { 
      UT_ReportError("SetBasicParameters: In function call!"); 
      return; 
    } 
    break; 
  } 
   
   
  /* ACQ_ns */ 
   
  ACQ_ns_list_size = PVM_NEchoImages; 
 
  ParxRelsParRelations("ACQ_ns_list_size",Yes); 
  for(echo=0; echo<PVM_NEchoImages; echo++) 
    ACQ_ns_list[echo] = 1; 
  NS = ACQ_ns = ACQ_ns_list[0]; 
   
   
   
  /* NECHOES */ 
   
  NECHOES = NEchoes+2*Navigator_flag*PVM_NEchoImages; 
   
   
  /* ACQ_obj_order */ 
   
  PARX_change_dims("ACQ_obj_order",NI); 
   
  ATB_SetAcqObjOrder( nSlices, PVM_ObjOrderList, PVM_NEchoImages, 1); 
  if( PVM_ErrorDetected == Yes ) 
  { 
    UT_ReportError("SetBasicParameters: In function call!"); 
    return; 
  } 
   
   
  /* DS */ 
   
  DS = NDummyScans; 
  ACQ_DS_enabled = Yes; 
   
   
  ATB_DisableAcqUserFilter(); 
  if( PVM_ErrorDetected == Yes ) 
  { 
    UT_ReportError("SetBasicParameters: In function call!"); 
      return; 
  } 
 
  ATB_SetAcqScanSize( One_scan ); 
  if( PVM_ErrorDetected == Yes ) 
  { 
    UT_ReportError("SetBasicParameters: In function call!"); 
    return; 
  } 
   
   
  DB_MSG(("<--SetBasicParameters\n")); 
} 
 
void SetFrequencyParameters( void ) 
{ 
  int nslices; 
   
  DB_MSG(("-->SetFrequencyParameters\n")); 
   
   
  ATB_SetNuc1(PVM_Nucleus1); 
   
  sprintf(NUC2,"off"); 
  sprintf(NUC3,"off"); 
  sprintf(NUC4,"off"); 
  sprintf(NUC5,"off"); 
  sprintf(NUC6,"off"); 
  sprintf(NUC7,"off"); 
  sprintf(NUC8,"off"); 
   
  ATB_SetNucleus(PVM_Nucleus1); 
   
   
  if( PVM_ErrorDetected == Yes ) 
  { 
    UT_ReportError("SetFrequencyParameters: In function call!"); 
    return; 
  } 
   
  /* setting of SW_h, DIGMOD, DSPFIRM and AQ_mod */ 
 
  ATB_SetDigPars(); 
 
   
  ACQ_O1_mode = BF_plus_Offset_list; 
  ParxRelsParRelations("ACQ_O1_mode",Yes); 
   
  ACQ_O2_mode = BF_plus_Offset_list; 
  ParxRelsParRelations("ACQ_O2_mode",Yes); 
   
  ACQ_O3_mode = BF_plus_Offset_list; 
  ParxRelsParRelations("ACQ_O3_mode",Yes); 
   
  O1 = 0.0; 
  O2 = 0.0; 
  O3 = 0.0; 
  O4 = 0.0; 
  O5 = 0.0; 
  O6 = 0.0; 
  O7 = 0.0; 
  O8 = 0.0; 
  
  
  /* Set BF's to working freuncies on used channels */
  ACQ_BF_enable = No;
  BF1 = PVM_FrqWork[0];
  BF2 = PVM_FrqWork[1];
  /* call relations of BF1 (no need for other BF's) */
  ParxRelsParRelations("BF1", Yes); 
  
  nslices = GTB_NumberOfSlices( PVM_NSPacks, PVM_SPackArrNSlices ); 
  if( PVM_ErrorDetected == Yes ) 
  { 
    UT_ReportError("SetFrequencyParameters: In function call!"); 
    return; 
  } 
   
  ATB_SetAcqO1List( nslices, 
                    PVM_ObjOrderList, 
                    PVM_SliceOffsetHz ); 
  if( PVM_ErrorDetected == Yes ) 
  { 
    UT_ReportError("SetFrequencyParameters: In function call!"); 
    return; 
  } 
   
  ATB_SetAcqO1BList( nslices, 
                     PVM_ObjOrderList, 
                     PVM_ReadOffsetHz); 
   
   
  ATB_SetRouting(); 
   
  if( PVM_ErrorDetected == Yes ) 
  { 
    UT_ReportError("SetFrequencyParameters: In function call!"); 
    return; 
  } 
   
   
   
  DB_MSG(("<--SetFrequencyParameters\n")); 
} 
 
void SetGradientParameters( void ) 
{ 
  int spatDim, dim; 
  /* added by J. Zhang */  
  double grad_ratio1; 
  /* end */ 
  DB_MSG(("-->SetGradientParameters\n")); 
   
   /* when there is navigator echo, the ACQ phase factor is increased by 2 */  
  ATB_SetAcqPhaseFactor( PVM_RareFactor + 2 * Navigator_flag ); 
   
  if( PVM_ErrorDetected == Yes ) 
  { 
    UT_ReportError("SetGradientParameters: In function call!"); 
    return; 
  } 
   
   
  spatDim = PTB_GetSpatDim(); 
   
  dim = PARX_get_dim("ACQ_phase_encoding_mode", 1 ); 
  PARX_change_dims("ACQ_phase_encoding_mode", spatDim ); 
  PARX_change_dims("ACQ_phase_enc_start", spatDim ); 
   
 
  switch(spatDim) 
  { 
    case 3: 
      ACQ_phase_encoding_mode[2] = User_Defined_Encoding; 
      ACQ_phase_enc_start[2] = -1; /* set, but no used */ 
      ACQ_spatial_size_2 = PVM_EncMatrix[2]; 
      ParxRelsCopyPar("ACQ_spatial_phase_2","PVM_EncValues2");  
      /* no break */ 
    case 2: 
      ACQ_phase_encoding_mode[1] = User_Defined_Encoding;;
      ACQ_phase_enc_start[1] = -1.0; /* set, but no used */
      ACQ_spatial_size_1 = PVM_EncMatrix[1];
      ParxRelsCopyPar("ACQ_spatial_phase_1","PVM_EncValues1");
      /* no break */ 
    default: 
      ACQ_phase_encoding_mode[0] = Read; 
      ACQ_phase_enc_start[0] = -1; 
  } 
 
    
  ATB_SetAcqGradMatrix( PVM_NSPacks, PVM_SPackArrNSlices, 
   PtrType3x3 PVM_SPackArrGradOrient[0], 
   PVM_ObjOrderList ); 
   
  if( PVM_ErrorDetected == Yes ) 
  { 
    UT_ReportError("SetGradientParameters: In function call!"); 
    return; 
  } 
   
   
  ACQ_scaling_read  = 1.0; 
  ACQ_scaling_phase = 1.0; 
  ACQ_scaling_slice = 1.0; 
   
  ACQ_rare_factor = PVM_RareFactor + 2*Navigator_flag; 
   
  ACQ_grad_str_X = 0.0; 
  ACQ_grad_str_Y = 0.0; 
  ACQ_grad_str_Z = 0.0; 
   
  strcpy(GRDPROG, ""); 
   
  /*grad_ratio1=PVM_ExSliceRephaseTime/PVM_2dPhaseGradientTime*3.14159z2653589*0.5; */
  ACQ_gradient_amplitude[0] = PVM_ExSliceGradient;
  ACQ_gradient_amplitude[1] = -PVM_ExSliceRephaseGradient;
  ACQ_gradient_amplitude[2] = PVM_ExSliceGradient;
  ACQ_gradient_amplitude[3] = SliceSpoilerStrength;
  ACQ_gradient_amplitude[4] = 0.01*dgro*PVM_ReadDephaseGradient;
  ACQ_gradient_amplitude[5] = PVM_ReadGradient;
  ACQ_gradient_amplitude[6] = PVM_2dPhaseGradient;
  ACQ_gradient_amplitude[7] = PVM_3dPhaseGradient;
  ACQ_gradient_amplitude[8] = -PVM_2dPhaseGradient;
  ACQ_gradient_amplitude[9] = -PVM_3dPhaseGradient;
  ACQ_gradient_amplitude[10] = BlipGradient_1;
  ACQ_gradient_amplitude[11] = BlipGradient_2;
  ACQ_gradient_amplitude[12] = ReadRewindingGradient;


  if( PVM_ErrorDetected == Yes ) 
  { 
    UT_ReportError("SetGradientParameters: In function call!"); 
    return; 
  } 
   
  DB_MSG(("<--SetGradientParameters\n")); 
} 
 
void SetInfoParameters( void ) 
{ 
  int slices, i, spatDim; 
 
  DB_MSG(("-->SetInfoParameters\n")); 
   
  spatDim = PTB_GetSpatDim(); 
  if( PVM_ErrorDetected == Yes ) 
  { 
    UT_ReportError("SetInfoParameters: In function call!"); 
    return; 
  } 
   
  ATB_SetAcqMethod(); 
   
  ATB_SetAcqFov( Spatial, spatDim, PVM_Fov, PVM_AntiAlias ); 
  if( PVM_ErrorDetected == Yes ) 
  { 
    UT_ReportError("SetInfoParameters: In function call!"); 
    return; 
  } 
   
  ACQ_flip_angle = PVM_ExcPulseAngle; 
 
  ACQ_n_echo_images = PVM_NEchoImages; 
  ACQ_n_movie_frames = 1; 
   
  PARX_change_dims("ACQ_echo_time",PVM_NEchoImages); 
  for(i=0; i<PVM_NEchoImages; i++) 
    ACQ_echo_time[i] = EffectiveTE[i]; 
   
  PARX_change_dims("ACQ_inter_echo_time",1); 
  ACQ_inter_echo_time[0] = PVM_EchoTime; 
   
  PARX_change_dims("ACQ_repetition_time",1); 
  ACQ_repetition_time[0] = PVM_RepetitionTime; 
   
  PARX_change_dims("ACQ_recov_time",1); 
  ACQ_recov_time[0] =  PVM_RepetitionTime - PVM_ExSlicePulseLength; 
   
  PARX_change_dims("ACQ_inversion_time",1); 
  ACQ_inversion_time[0] = PVM_InversionTime; 
   
  ATB_SetAcqSliceAngle( PtrType3x3 PVM_SPackArrGradOrient[0], 
   PVM_NSPacks ); 
   
  ACQ_slice_orient = Arbitrary_Oblique; 
   
  ACQ_slice_thick = PVM_SliceThick; 
   
  slices = GTB_NumberOfSlices( PVM_NSPacks, PVM_SPackArrNSlices ); 
  if( PVM_ErrorDetected == Yes ) 
  { 
    UT_ReportError("SetInfoParameters: In function call!"); 
    return; 
  } 
   
  PARX_change_dims("ACQ_slice_offset",slices); 
  PARX_change_dims("ACQ_read_offset",slices); 
  PARX_change_dims("ACQ_phase1_offset",slices); 
  PARX_change_dims("ACQ_phase2_offset",slices); 
   
  for(i=0;i<slices;i++) 
  { 
    ACQ_slice_offset[i]  = PVM_SliceOffset[i]; 
    ACQ_read_offset[i]   = PVM_ReadOffset[i]; 
    ACQ_phase1_offset[i] = PVM_Phase1Offset[i]; 
    ACQ_phase2_offset[i] = PVM_Phase2Offset[i]; 
  } 
 
  ACQ_read_ext = (int)PVM_AntiAlias[0]; 
   
  PARX_change_dims("ACQ_slice_sepn", slices==1 ? 1 : slices-1); 
   
  if( slices == 1 ) 
  { 
    ACQ_slice_sepn[0] = 0.0; 
  } 
  else 
  { 
    for( i=1; i<slices;i++ ) 
    { 
      ACQ_slice_sepn[i-1]=PVM_SliceOffset[i]-PVM_SliceOffset[i-1]; 
    } 
  } 
   
  ATB_SetAcqSliceSepn( PVM_SPackArrSliceDistance, 
                       PVM_NSPacks ); 
   
   
   
  ATB_SetAcqPatientPosition(); 
   
  ATB_SetAcqExpType( Imaging ); 
   
  ACQ_n_t1_points = 1; 
   
  if( ParxRelsParHasValue("ACQ_transmitter_coil") == No ) 
  { 
    ACQ_transmitter_coil[0] = '\0'; 
  } 
   
   
  if( ParxRelsParHasValue("ACQ_contrast_agent") == No ) 
  { 
    ACQ_contrast_agent[0] = '\0'; 
  } 
 
  if( ParxRelsParHasValue("ACQ_contrast") == No ) 
  { 
    ACQ_contrast.volume = 0.0; 
    ACQ_contrast.dose = 0.0; 
    ACQ_contrast.route[0] = '\0'; 
    ACQ_contrast.start_time[0] = '\0'; 
    ACQ_contrast.stop_time[0] = '\0'; 
  } 
   
  ParxRelsParRelations("ACQ_contrast_agent",Yes); 
   
  ACQ_position_X = 0.0; 
  ACQ_position_Y = 0.0; 
  ACQ_position_Z = 0.0; 
   
  PARX_change_dims("ACQ_temporal_delay",1); 
  ACQ_temporal_delay[0] = 0.0; 
   
  ACQ_RF_power = 0; 
   
  ACQ_flipback = No; 
   
  DB_MSG(("<--SetInfoParameters\n")); 
   
} 
 
void SetMachineParameters( void ) 
{ 
  double dval; 
  DB_MSG(("-->SetMachineParameters\n")); 
 
   
  if( ParxRelsParHasValue("ACQ_word_size") == No ) 
  { 
    ACQ_word_size = _32_BIT; 
  } 
   
  /*
  dval = PVM_GradDelayTime + PVM_2dPhaseGradientTime - 0.01; 
  dval = MAX_OF(PVM_DigEndDelOpt,dval); */

  dval = MAX_OF(PVM_DigEndDelOpt, CFG_GradientRiseTime())+ 0.02;
 
  DEOSC = (PVM_AcquisitionTime  + dval)*1000.0; 
  ACQ_scan_shift = -1; 
  ParxRelsParRelations("ACQ_scan_shift",Yes); 
   
  DE = DE < 6.0 ? 6.0: DE; 
  PAPS = QP; 
   
  ACQ_BF_enable = Yes; 
   
  DB_MSG(("<--SetMachineParameters\n")); 
} 
 
void SetPpgParameters( void ) 
{ 
  DB_MSG(("-->SetPpgParameters\n")); 
   
  if( ParxRelsParHasValue("ACQ_trigger_enable") == No ) 
  { 
    ACQ_trigger_enable = No; 
  } 
   
  if( ParxRelsParHasValue("ACQ_trigger_reference") == No ) 
  { 
    ACQ_trigger_reference[0] = '\0'; 
  } 
   
  if( ParxRelsParHasValue("ACQ_trigger_delay") == No ) 
  { 
    ACQ_trigger_delay = 0; 
  } 
   
  ParxRelsParRelations("ACQ_trigger_reference",Yes); 
   
   
  ACQ_vd_list_size=1; 
  PARX_change_dims("ACQ_vd_list",1); 
  ACQ_vd_list[0] = 1e-6; 
  ParxRelsParRelations("ACQ_vd_list",Yes); 
   
  ACQ_vp_list_size=1; 
  PARX_change_dims("ACQ_vp_list",1); 
  ACQ_vp_list[0] = 1e-6; 
  ParxRelsParRelations("ACQ_vp_list",Yes); 
   
   
  ATB_SetPulprog("dwGRASE4f1.ppg"); 
  if(PVM_SelIrOnOff) 
  { 
    D[0] = PVM_InterGradientWaitTime / 1000.0; 
    D[10] = SliceSegEndDelay/1000.0; 
  } 
  else 
  { 
    D[0]  = ((PVM_RepetitionTime - PVM_MinRepetitionTime)/NSLICES  
    + PVM_InterGradientWaitTime) / 1000.0; 
    D[10] = 0.00001; 
  } 
  D[1]  = DWI3DFSE_TED2 / 1000.0; 
  D[2]  = D[1];
  D[3]  = PVM_GradDelayTime / 1000.0; 
  D[3]  = MAX_OF(D[3], 1e-6);  /* min d3 in case PVM_GradDelayTime==0  */ 
  D[4]  = PVM_RampTime / 1000.0; 
  D[5]  = (DiffusionGradientDuration +2*DiffusionRampTime )/ 1000.0;
  D[6]  = PVM_2dPhaseGradientTime/1000.0; 
  D[7] = MinDiffusionSpace/1000.0;
  if (Bipolar_diffusion == No)
    {
      D[7] = DiffusionGradientSeparation/1000.0 - D[5]-4*D[4]-2*D[3]-RefPulse.Length/1000.0;
      D[1] = (PVM_EchoTime - MinTE1)/2000.0;
      D[2] = (PVM_EchoTime - MinTE2)/2000.0;
    }
  D[8] = CFG_AmplifierEnable()/1000.0; 
  D[11] = (PVM_ExSliceRephaseTime - 2.0*PVM_RampTime) / 1000.0; 
  D[12] = DiffusionGradientSeparation / 1000.0; 
  D[13] = (SliceSpoilerDuration-2*PVM_RampTime)/1000.0; 
  D[14] = Echo_Separation/1000.0; 
  D[15] = PD_time/1000.0; 
  D[16] = BlipDuration_2/1000.0; 
  D[17] = Rort/1000.0;
  D[18] = D[3]+D[4]-(DE-DEPA)/1000000.0;
  D[19] = idle_time/1000.0;
 
  /* set shaped pulses     */ 
  sprintf(TPQQ[0].name,ExcPulse.Filename); 
  sprintf(TPQQ[1].name,RefPulse.Filename); 
  if(PVM_DeriveGains == Yes) 
  { 
    TPQQ[0].power  = ExcPulse.Attenuation; 
    TPQQ[1].power  = RefPulse.Attenuation; 
  } 
  TPQQ[0].offset = 0.0; 
  TPQQ[1].offset = 0.0; 
   
  ParxRelsParRelations("TPQQ[0]",Yes); 
  ParxRelsParRelations("TPQQ[1]",Yes);
  
  /* set duration of pulse, in this method P[0] is used          */ 
  P[0] = ExcPulse.Length * 1000; 
  P[1] = RefPulse.Length * 1000; 
  ParxRelsParRelations("P",Yes); 
   
  /* counters used in pulse program */ 
  L[1] = NDummyScans*(PVM_RareFactor + 2*Navigator_flag); 
  L[2] = (PVM_EncMatrix[1])/(PVM_RareFactor+2*Navigator_flag);  
  L[3] = PVM_RareFactor;
  L[4] = PVM_ppgInt1;
  DB_MSG(("<--SetPpgParameters\n")); 
} 
 
 
#if DEBUG 
void printTiming(void) 
{ 
  double te1,te2; 
 
  te1=(P[0]+P[1])/2000 + (5*D[4]+D[11]+D[1]+D[5]+D[3])*1000 +0.01; 
  te2=      P[1]/1000  + (8*D[4]+2*D[5]+4*D[3]+2*D[2]+2*D[6])*1000+ 
    PVM_AcquisitionTime; 
 
  DB_MSG(("te1: %f should be %f diff %f\n" 
   "te2: %f should be %f diff %f\n", 
   te1,PVM_EchoTime/2,te1-PVM_EchoTime/2, 
   te2,PVM_EchoTime,te2-PVM_EchoTime)); 
 
 
  return; 
} 
 
#endif  
