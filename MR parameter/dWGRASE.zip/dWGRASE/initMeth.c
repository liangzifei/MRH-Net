/***************************************************************
 * 
 * $Source: /pv/CvsTree/pv/gen/src/prg/methods/RARE/initMeth.c,v $
 * 
 * Copyright (c) 2002-2004 
 * Bruker BioSpin MRI GmbH 
 * D-76275 Ettlingen, Germany 
 * 
 * All Rights Reserved 
 * 
 * $Id: initMeth.c,v 1.17.2.5 2005/08/30 15:54:31 sako Exp $ 
 * 
 ****************************************************************/ 
 
static const char resid[] = "$Id: initMeth.c,v 1.17.2.5 2005/08/30 15:54:31 sako Exp $(C) 2002-2004 Bruker BioSpin MRI GmbH"; 
 
#define DEBUG  0 
#define DB_MODULE 0 
#define DB_LINE_NR 0 
 
 
#include "method.h" 
 
/*:=MPB=:=======================================================* 
 * 
 * Global Function: initMeth 
 * 
 * Description: This procedure is implicitly called when this 
 * method is selected. 
 * 
 * Error History:  
 * 
 * Interface:       */ 
 
void initMeth() 
/*:=MPE=:=======================================================*/ 
{ 
  int dimRange[2] = { 2,3 }; 
  int lowMat[3]   = { 32, 32, 8 }; 
  int upMat[3]    = { 2048, 2048, 256 }; 
  int i = 0; 
 
  DB_MSG(("-->initMeth\n")); 
 
  /* which version of toolboxes should be active */ 
  PTB_VersionRequirement( Yes,20050101,""); 
   
  
   
  /*  Initialize NA ( see code in parsRelations ) */ 
  Local_NAveragesRange(); 
  if(ParxRelsParHasValue("PVM_NRepetitions") == No) 
    PVM_NRepetitions = 1; 
  /* init. dummy scans */ 
  dsRange(); 
 
  /*  
   * Which parameter classes (see parDefs.h) should be 
   * hidden in routine mode  
   */ 
 
  PTB_SetUserTypeClasses( "Nuclei," 
     "Sequence_Details," 
     "RF_Pulses" ); 
 
  if(ParxRelsParHasValue("PVM_RepetitionTime") == No) 
    PVM_RepetitionTime = 1000.0; 
  if(ParxRelsParHasValue("PVM_EchoTime") == No) 
    PVM_EchoTime = 20.0; 
  if(ParxRelsParHasValue("PVM_DeriveGains") == No) 
    PVM_DeriveGains = Yes; 
 
  /* Initialisation of rf pulse parameters */ 
 
  /*  
   * 1: flip angle in the scan edidor  
   * (use for refoc. pulse angle in this method) 
   */ 
 
  ParxRelsShowInEditor("PVM_ExcPulseAngle"); 
   
 
  /*  
   * 2: pulses declared in parDefinitions.h  
   * in this case - ExcPulse and RefPulse.  
   */ 
 
  if(ParxRelsParHasValue("ExcPulse") == No) 
    STB_InitRFPulse(&ExcPulse, 
      CFG_RFPulseDefaultShapename(LIB_EXCITATION), 
      1.0,  /* default duration in ms */ 
      90.0); 
  ExcPulseRange(); 
  if(ParxRelsParHasValue("RefPulse") == No) 
    STB_InitRFPulse(&RefPulse, 
      CFG_RFPulseDefaultShapename(LIB_REFOCUS), 
      1.0, /* default duration in ms */ 
      180.0 ); 
  RefPulseRange(); 
   
   
  /* 3: the corresponding pulse enums */ 
  STB_InitExcPulseEnum("ExcPulseEnum"); 
  STB_InitRfcPulseEnum("RefPulseEnum"); 
   
 
  /* Initialisation of nucleus */   
  STB_InitNuclei(1); 
   
  /*  
   * Gradient limits in % of max. Value 57 (1/sqrt(3)) 
   * is needed for arbitrary oblique slices.  
   */ 
 
  PVM_LimReadDephaseGradient = 57.0; 
  PVM_Lim2dPhaseGradient = 57.0; 
  PVM_Lim3dPhaseGradient = 57.0; 
   
  /* Initialisation of atoms */ 
   
  if(ParxRelsParHasValue("PVM_ReadDephaseTime") == No) 
    PVM_ReadDephaseTime = 1.0; 
  if(ParxRelsParHasValue("PVM_2dPhaseGradientTime") == No) 
    PVM_2dPhaseGradientTime = 1.0; 
  STB_InitReadAtoms();   
  STB_InitExSliceAtoms(); 
  STB_Init2dPhaseAtoms(); 
  STB_Init3dPhaseAtoms(); 
   
  /* Initialisation of spoilers */ 
   
  if(ParxRelsParHasValue("SliceSpoilerDuration") == No) 
    SliceSpoilerDuration = 2; 
  if(ParxRelsParHasValue("SliceSpoilerStrength") == No) 
    SliceSpoilerStrength = 10; 
 
  /* added by J. Zhang */ 
  if(ParxRelsParHasValue("PVM_ExSliceRephaseTime")==No) 
    PVM_ExSliceRephaseTime = 2.0; 
  if(ParxRelsParHasValue("PD_time") == No) 
    PD_time = 2.0; 

  /* phase encoding start */ 
  if (ParxRelsParHasValue("Dgro") == No) Dgro=100; 
  if (ParxRelsParHasValue("Groa") == No) Groa=100;
  if (ParxRelsParHasValue("Rort") == No) Rort=0.2;
  /* 
  if(ParxRelsParHasValue("PhaseEncodingStart") == No) 
    PhaseEncodingStart = -1.0; 
  if(ParxRelsParHasValue("AdjustStart") == No) 
    AdjustStart = Yes; 
  */ 
  /* Initialization of Diffusion Gradients */ 
  STB_InitDiffusionPreparation(Yes);
  if (ParxRelsParHasValue("NumAoImg")==No) NumAoImg=4;
       PVM_DwAoImages = 4;
  if (ParxRelsParHasValue("AoGradient")==No) 
     AoGradient = 4.0; /* in Gauss/cm */

  DIFF_NUMBER = PVM_DwAoImages + PVM_DwNDiffExpEach;
  if (ParxRelsParHasValue("DiffusionGradientX") == No || 
      ParxRelsParHasValue("DiffusionGradientY") == No || 
      ParxRelsParHasValue("DiffusionGradientZ") == No)
  { 
	PARX_change_dims("DiffusionGradientX",DIFF_NUMBER); 
	PARX_change_dims("DiffusionGradientY",DIFF_NUMBER); 
	PARX_change_dims("DiffusionGradientZ",DIFF_NUMBER); 
	PARX_change_dims("bvalues",DIFF_NUMBER); 
	PVM_ppgGradAmpArray1Size=DIFF_NUMBER; 

	for (i=0;i<PVM_DwAoImages;i++)  
	{ 
		PVM_DwGradRead[i]=0;
		PVM_DwGradRead[i]=0;
		PVM_DwGradSlice[i]=AoGradient*4256.7/CFG_GradCalConst(PVM_Nucleus1);
	} 
	
	for (i=0;i<DIFF_NUMBER;i++)  
	{ 
		DiffusionGradientX[i+PVM_DwAoImages]=PVM_DwGradRead[i+PVM_DwAoImages]*CFG_GradCalConst(PVM_Nucleus1)/4256.7; 
		DiffusionGradientY[i+PVM_DwAoImages]=PVM_DwGradPhase[i+PVM_DwAoImages]*CFG_GradCalConst(PVM_Nucleus1)/4256.7; 
		DiffusionGradientZ[i+PVM_DwAoImages]=PVM_DwGradSlice[i+PVM_DwAoImages]*CFG_GradCalConst(PVM_Nucleus1)/4256.7; 
	} 
    
  } 
  if (ParxRelsParHasValue("DiffusionAdjX") == No)
      {
        DiffusionAdjX[0] = 0.7;
        DiffusionAdjX[1] = -3.0;
      }
  if (ParxRelsParHasValue("DiffusionAdjY") == No)
    {
      DiffusionAdjY[0] = 1.6;
      DiffusionAdjY[1] = -2.8;
    }
  if (ParxRelsParHasValue("DiffusionAdjZ") == No)
     {
       DiffusionAdjZ[0] = 1.2;
       DiffusionAdjZ[1] = -3.0;
     }

  DAX1 = DiffusionAdjX[0];
  DAX2 = DiffusionAdjX[1];
  DAY1 = DiffusionAdjY[0];
  DAY2 = DiffusionAdjY[1];
  DAZ1 = DiffusionAdjZ[0];
  DAZ2 = DiffusionAdjZ[1];

  ParxRelsMakeNonEditable("DiffusionGradientX"); 
  ParxRelsMakeNonEditable("DiffusionGradientY"); 
  ParxRelsMakeNonEditable("DiffusionGradientZ"); 
  ParxRelsMakeNonEditable("Bvalues"); 


  if (ParxRelsParHasValue("DiffusionRampTime")==No) 
     DiffusionRampTime = 0.1; 
  if (ParxRelsParHasValue("MinDiffusionSpace") == No) 
     MinDiffusionSpace=0.20;  
   /* in ms , it should be bigger than gradient rising time. */ 
 
  
  Diffusion_Timing_Range(); 

  if (ParxRelsParHasValue("AcqArr_len")==No) 
     AcqArr_len = 1000; 
  PVM_ppgGradShape1Size=200; 
   ParxRelsParRelations("PVM_ppgGradShape1Size",Yes);
  PVM_ppgGradShape2Size=AcqArr_len; 
   ParxRelsParRelations("PVM_ppgGradShape2Size",Yes);
  PVM_ppgGradShape3Size=AcqArr_len; 
   ParxRelsParRelations("PVM_ppgGradShape3Size",Yes);
 
 
  /* navigator echoes */ 
  if (ParxRelsParHasValue("Navigator_Echoes")==No) 
    { Navigator_Echoes = No; 
      navigator_flag = 0; 
     } 
  
  if (ParxRelsParHasValue("Bipolar_diffusion")==No) 
    { 
        Bipolar_diffusion = No; 
        PVM_ppgInt1  = 0;
    } 
  /* crusher gradients around 180Rf */ 
  crusher_num=PVM_NEchoImages*PVM_RareFactor+3; 
 
  if(ParxRelsParHasValue("SpoilerDuration") == No) 
    SpoilerDuration = 2; 
  if(ParxRelsParHasValue("SpoilerStrengthX") == No ||  
     ParxRelsParHasValue("SpoilerStrengthY") == No ||  
     ParxRelsParHasValue("SpoilerStrengthZ") == No) 
    { 
      PARX_change_dims("SpoilerStrengthX",crusher_num); 
      PARX_change_dims("SpoilerStrengthY",crusher_num); 
      PARX_change_dims("SpoilerStrengthZ",crusher_num); 
   PVM_ppgGradAmpArray4Size=crusher_num; 
   ParxRelsParRelations("PVM_ppgGradAmpArray4Size",Yes);     
   PVM_ppgGradAmpArray5Size=crusher_num; 
   ParxRelsParRelations("PVM_ppgGradAmpArray5Size",Yes);  
   PVM_ppgGradAmpArray6Size=crusher_num; 
   ParxRelsParRelations("PVM_ppgGradAmpArray6Size",Yes);  
      for (i=0;i<crusher_num;i++) 
 { 
   SpoilerStrengthX[i]=3.0; 
   SpoilerStrengthY[i]=3.0; 
   SpoilerStrengthZ[i]=8.0; 
   PVM_ppgGradAmpArray4[i]=SpoilerStrengthX[i]*0.01; 
   PVM_ppgGradAmpArray5[i]=SpoilerStrengthY[i]*0.01; 
   PVM_ppgGradAmpArray6[i]=SpoilerStrengthZ[i]*0.01; 
 } 
    }   
  /* echo spacing control */ 
  if (ParxRelsParHasValue("Echo_Separation")==No) Echo_Separation=0.1; 
 
  /* end */ 
  
 
  /*  
   * Initialisation of geometry parameters  
   * A: in-plane  
   */ 
 
  STB_InitStandardInplaneGeoPars(2,dimRange,lowMat,upMat,No); 
   
  /* B: slice geometry */ 
 
  STB_InitSliceGeoPars(0,0,0); 
 
  /* initialize digitizer parameter */ 
 
  STB_InitDigPars(); 
  EffSWhRange(); 
 
  /* Encoding */ 
  STB_InitEncoding(); 
 
  /* phase encoding start is defined by new encoding group */ 
  /* ParxRelsResetPar("PhaseEncodingStart");*/ 
   
  /* echo parameters */ 
   
  if(ParxRelsParHasValue("PVM_RareFactor") == No) 
    PVM_RareFactor = 1; 
  if(ParxRelsParHasValue("PVM_NEchoImages") == No) 
    PVM_NEchoImages = 1; 

  PVM_NEchoScan1 = 1; 
  PVM_NEchoScan2 = 1; 
  ParxRelsShowInEditor("PVM_EchoTime1,PVM_EchoTime2"); 
  ParxRelsMakeNonEditable("NEchoes,PVM_NEchoScan1,PVM_NEchoScan2"); 
  /*ParxRelsMakeEditable("PVM_FlipBackOnOff"); 
  ParxRelsShowInEditor("PVM_FlipBackOnOff"); */ 
  ParxRelsShowInEditor("PVM_EchoTime1,PVM_EchoTime2"); 
  ParxRelsHideClassInEditor("ScanEditorInterface"); 
  ParxRelsShowInFile("PVM_EchoTime1,PVM_EchoTime2"); 
 
  /* PhaseEncodingStart only used to convert old protocols */ 
  /*ParxRelsHideInEditor("PhaseEncodingStart"); 
  ParxRelsHideInFile("PhaseEncodingStart"); */ 
   
  /* not a csi experiment */ 
  PTB_SetSpectrocopyDims( 0, 0 ); 
   
  /* activating motion suppression */ 
  if (ParxRelsParHasValue("PVM_MotionSupOnOff") == 0) 
     PVM_MotionSupOnOff = Off; 
  PARX_hide_pars(NOT_HIDDEN,"PVM_MotionSupOnOff");  
    
 
  /* Initialisation of modules */ 
  STB_InitFatSupModule(); 
  STB_InitMagTransModule(); 
  STB_InitSatSlicesModule(); 
  STB_InitFlowSaturationModule(); 
  STB_InitTriggerModule(); 
  STB_InitEvolutionModule(); 
  STB_InitSelIrModule(); 
   
   
  /*  
   * Once all parameters have initial values, the backbone is called 
   * to assure they are consistent  
   */ 
   
 
  backbone(); 
 
  DB_MSG(( "<--initMeth\n" )); 
 
} 
 
 
 
 
/****************************************************************/ 
/*  E N D   O F   F I L E    */ 
/****************************************************************/ 
 
 
 
 
 
 
 
 
   
