/****************************************************************
 * 
 * $Source: /pv/CvsTree/pv/gen/src/prg/methods/RARE/parsLayout.h,v $ 
 * 
 * Copyright (c) 1999-2002 
 * Bruker BioSpin MRI GmbH 
 * D-76275 Ettlingen, Germany 
 * 
 * All Rights Reserved 
 * 
 * $Id: parsLayout.h,v 1.11.2.4 2005/08/30 15:54:31 sako Exp $ 
 * 
 ****************************************************************/ 
 
/****************************************************************/ 
/* PARAMETER CLASSES            */ 
/****************************************************************/ 
 
 
/*--------------------------------------------------------------* 
 * Definition of the PV class... 
 *--------------------------------------------------------------*/ 
parclass 
{  
   DiffusionRampTime; 
   MinDiffusionSpace; 
   NumAoImg;
   AoGradient; 
   Bvalues;
   DiffusionGradientX; 
   DiffusionGradientY; 
   DiffusionGradientZ;
} Diffusion_Details; 
 
parclass 
{ 
  AcqArr_len;
  PVM_EffSWh; 
  PVM_ExSliceRephaseTime;
  PVM_2dPhaseGradientTime; 
  Rort;
  Dgro; 
  Groa;
  SpoilerStrengthX; 
  SpoilerStrengthY; 
  SpoilerStrengthZ; 
  Echo_Separation; 
  PD_time; 
  Navigator_Echoes; 
  SliceSpoilerDuration; 
  SliceSpoilerStrength; 
  DigitizerPars; 
} GRASE_Details; 
 
parclass 
{ 
  PVM_SliceBandWidthScale; 
  ExcPulseEnum; 
  ExcPulse; 
  RefPulseEnum; 
  RefPulse; 
} RF_Pulses; 
 
 
parclass 
{ 
 
  NDummyScans; 
 
  PVM_TriggerModule; 
  Trigger_Parameters; 
 
  PVM_EvolutionOnOff; 
  Evolution_Parameters; 
 
  PVM_SelIrOnOff; 
  Selective_IR_Parameters; 
 
  PVM_FatSupOnOff; 
  Fat_Sup_Parameters; 
  
  PVM_MagTransOnOff; 
  Magn_Transfer_Parameters; 
  
  PVM_FovSatOnOff; 
  Sat_Slices_Parameters; 
  
  PVM_InFlowSatOnOff; 
  Flow_Sat_Parameters; 
 
  PVM_MotionSupOnOff; 
  
} Preparation; 
 
/* The following class is defined to assure that parameters of the  
 * scan editor are properly displayed. */ 
parclass 
{ 
  PVM_EchoTime1; 
  PVM_EchoTime2; 
} ScanEditorInterface; 
 
parclass 
{ 
  Method; 
  PVM_EchoTime; 
  EffectiveTE; 
  PVM_RepetitionTime; 
  PVM_NAverages;  
  PVM_RareFactor; 
  PVM_NEchoImages; 
  PVM_ScanTimeStr; 
  PVM_UserType; 
  PVM_DeriveGains; 
  RF_Pulses; 
  Nuclei; 
  Diffusion_Details; 
  Encoding; 
  GRASE_Details; 
  StandardInplaneGeometry; 
  StandardSliceGeometry; 
  Preparation; 
  ScanEditorInterface; 
} MethodClass; 
 
 
/****************************************************************/ 
/* E N D   O F   F I L E     */ 
/****************************************************************/ 
 
 
        
