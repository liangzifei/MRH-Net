/****************************************************************
 * 
 * $Source: /pv/CvsTree/pv/gen/src/prg/methods/RARE/parsDefinition.h,v $ 
 * 
 * Copyright (c) 1999-2001 
 * BRUKER MEDICAL GMBH 
 * D-76275 Ettlingen, Germany 
 * 
 * All Rights Reserved 
 * 
 * $Id: parsDefinition.h,v 1.6.2.3 2005/12/19 15:09:43 dwe Exp $ 
 * 
 ****************************************************************/ 
 
 
 
/****************************************************************/ 
/* INCLUDE FILES      */ 
/****************************************************************/ 
double parameter ReadGradRatio; 
double parameter ReadGradRatio1;
double parameter ReadGradRatio2;
double parameter ReadDephaseGradient1;
double parameter ReadRewindingGradient;
double parameter SliceGradRatio; 
double parameter Phase3dInteg; 
double parameter BlipInteg_2;
double parameter BlipInteg_3;
double parameter BlipGradient_1;
double parameter BlipGradient_2;
double parameter BlipGradient_3;
double parameter BlipDuration_2;
double parameter BlipDuration_3;
double parameter Phase2dInteg; 
double parameter MinTE1; 
double parameter MinTE2; 
double parameter EvolutionDuration; 
int    parameter DIFF_NUMBER;
double parameter DAX1;
double parameter DAX2;
double parameter DAY1;
double parameter DAY2;
double parameter DAZ1;
double parameter DAZ2;
double parameter Idle_time;
 
/***************************************/ 
/* parameters added by J. Zhang   */ 
/*************************************/ 
int parameter Navigator_flag; 
int parameter Crusher_num; 
double parameter DWI3DFSE_TED2; 
 
YesNo parameter 
{ 
  display_name "Use twin-navigator echoes"; 
  relations backbone; 
}Navigator_Echoes; 
 
YesNo parameter 
{ 
  display_name "Bipolar diffusion encoding"; 
  relations backbone; 
}Bipolar_diffusion; 


/* parameters added by Dan Wu   */
int parameter 
{ 
  display_name "Acquisition array length"; 
  format "%d"; 
  relations backbone; 
}AcqArr_len; 

 
double parameter 
{ 
  display_name "RO Dephase Control"; 
  format "%.2f"; 
  units "%"; 
  relations backbone; 
}Dgro; 

double parameter
{
  display_name "RO gradient balance";
  format "%.2f";
  units "%";
  relations backbone;
}Groa;

double parameter
{
  display_name "RO gradient ramptime";
  format "%.2f";
  units "ms";
  relations backbone;
}Rort;

double parameter 
{ 
  display_name "Echo Separation"; 
  format "%.2f"; 
  units "ms"; 
  relations backbone; 
}Echo_Separation; 
 
double parameter 
{ 
  display_name "Spoiler duration"; 
  format "%.2f"; 
  units "ms"; 
  relations backbone; 
} SpoilerDuration; 
 
double parameter 
{ 
  display_name "RO Spoiler strength"; 
  format "%.1f"; 
  units "%"; 
  relations backbone; 
} SpoilerStrengthX[]; 
 
double parameter 
{ 
  display_name "PE Spoiler strength"; 
  format "%.1f"; 
  units "%"; 
  relations backbone; 
} SpoilerStrengthY[]; 
 
double parameter 
{ 
  display_name "SS Spoiler strength"; 
  format "%.1f"; 
  units "%"; 
  relations backbone; 
} SpoilerStrengthZ[]; 
 
double parameter 
{ 
  display_name "b value"; 
  format "%.4f"; 
  units "s/mm2"; 
  relations backbone; 
}Bvalues[]; 
 
int parameter
{
   display_name "Num of A0 Imgs";
   relations backbone;
}NumAoImg;


double parameter 
{ 
   display_name "A0 Gradient"; 
   format "%.3f"; 
   units "G/cm"; 
   relations backbone; 
} AoGradient; 


double parameter 
{ 
   display_name "Diff Grad (RO)"; 
   format "%.3f"; 
   units "G/cm"; 
   relations backbone; 
} DiffusionGradientX[]; 
 
double parameter 
{ 
   display_name "Diff Grad (PE)"; 
   format "%.3f"; 
   units "G/cm"; 
   relations backbone; 
} DiffusionGradientY[]; 
 
double parameter 
{ 
   display_name "Diff Grad (SS)"; 
   format "%.3f"; 
   units "G/cm"; 
   relations backbone; 
} DiffusionGradientZ[]; 
 
double parameter 
{ 
  display_name "Diff Grad Ramp Time"; 
  format "%.2f"; 
  units "ms"; 
  relations Diffusion_Timing_rels; 
}DiffusionRampTime; 

double parameter
{
  display_name "Diffusion Grad Adj (RO)";
  format "%.4f";
  units "G/cm";
  relations backbone;
}DiffusionAdjX[2];

double parameter
{
  display_name "Diffusion Grad Adj (PE)";
  format "%.4f";
  units "G/cm";
  relations backbone;
}DiffusionAdjY[2];

double parameter
{
  display_name "Diffusion Grad Adj (SS)";
  format "%.4f";
  units "G/cm";
  relations backbone;
}DiffusionAdjZ[2];

 
double parameter 
{ 
    display_name "Minimum separation"; 
    format "%.2f"; 
    units "ms"; 
    relations Diffusion_Timing_rels; 
}MinDiffusionSpace; 
 
double parameter 
{ 
  display_name "Initial Delay Time"; 
  format "%.2f"; 
  units "ms"; 
  relations backbone; 
}PD_time; 
 
 
 
/************************************************/ 
/* End of parameters added by J. Zhang */ 
/***********************************************/ 
 
double parameter 
{ 
  display_name "Effective echo time"; 
  format "%.2f"; 
  units "ms"; 
  relations effTErels;  
} EffectiveTE[]; 
 
 
double parameter 
{ 
  display_name "Slice spoiler duration"; 
  format "%.2f"; 
  units "ms"; 
  relations backbone; 
} SliceSpoilerDuration; 
 
double parameter 
{ 
  display_name "Slice spoiler strength"; 
  format "%.1f"; 
  units "%"; 
  relations backbone; 
} SliceSpoilerStrength; 
 
PV_PULSE_LIST parameter 
{ 
  display_name "Excitation Pulse Choice"; 
  relations    ExcPulseEnumRelation; 
}ExcPulseEnum; 
 
 
PVM_RF_PULSE_TYPE parameter 
{ 
  display_name "Excitation Pulse"; 
  relations    ExcPulseRelation; 
}ExcPulse; 
 
PV_PULSE_LIST parameter 
{ 
  display_name "Refocusing Pulse Choice"; 
  relations    RefPulseEnumRelation; 
}RefPulseEnum; 
 
 
PVM_RF_PULSE_TYPE parameter 
{ 
  display_name "Refocusing Pulse"; 
  relations    RefPulseRelation; 
}RefPulse; 
 
int parameter 
{ 
  display_name "Number of echoes"; 
} NEchoes; 
 
double parameter 
{ 
  display_name "Phase encoding start"; 
  format "%.2f"; 
  relations encodingRelations; 
} PhaseEncodingStart; 
 
int parameter  
{ 
  display_name "Number of dummy scans"; 
  relations dsRelations; 
} NDummyScans; 
 
double parameter 
{ 
  display_name "Inter Slice Delay"; 
  relations backbone; 
  units "ms"; 
  format "%.2f"; 
}SliceSegDur; 
 
double parameter SliceSegDelay; 
double parameter MinSliceSegDur; 
double parameter SliceSegEndDelay; 
 
 
/****************************************************************/ 
/* E N D   O F   F I L E     */ 
/****************************************************************/ 
 
 
 
       
